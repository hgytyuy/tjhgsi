package com.mathewsachin.fategrandautomata.scripts.supportSelection

interface SupportSelectionProvider {
    fun select(): SupportSelectionResult
}