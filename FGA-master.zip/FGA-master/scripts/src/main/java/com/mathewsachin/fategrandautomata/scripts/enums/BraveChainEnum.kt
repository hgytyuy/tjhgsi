package com.mathewsachin.fategrandautomata.scripts.enums

enum class BraveChainEnum {
    None,
    WithNP,
    Avoid
}