package com.mathewsachin.fategrandautomata.scripts.enums

enum class SpamEnum {
    None, Spam, Danger
}