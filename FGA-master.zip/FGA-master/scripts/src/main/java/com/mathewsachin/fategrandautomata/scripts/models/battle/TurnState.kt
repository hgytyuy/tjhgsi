package com.mathewsachin.fategrandautomata.scripts.models.battle

class TurnState {
}