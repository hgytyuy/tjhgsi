package com.mathewsachin.fategrandautomata.scripts.enums

enum class ShuffleCardsEnum {
    None,
    NoEffective,
    NoNPMatching
}