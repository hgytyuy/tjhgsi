package com.mathewsachin.fategrandautomata.scripts.enums

enum class CardAffinityEnum {
    Normal,
    Weak,
    Resist
}