package com.mathewsachin.fategrandautomata.scripts.enums

enum class RefillResourceEnum {
    Copper,
    Bronze,
    Silver,
    Gold,
    SQ
}