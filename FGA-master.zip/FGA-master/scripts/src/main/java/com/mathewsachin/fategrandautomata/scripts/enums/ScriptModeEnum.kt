package com.mathewsachin.fategrandautomata.scripts.enums

enum class ScriptModeEnum {
    Battle,
    FP,
    Lottery,
    PresentBox,
    SupportImageMaker,
    CEBomb
}