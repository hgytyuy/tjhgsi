package com.mathewsachin.fategrandautomata.scripts.enums

enum class SupportSelectionModeEnum {
    First,
    Manual,
    Friend,
    Preferred
}