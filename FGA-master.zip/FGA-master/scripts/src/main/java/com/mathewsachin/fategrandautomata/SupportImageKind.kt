package com.mathewsachin.fategrandautomata

enum class SupportImageKind {
    Servant, CE, Friend
}