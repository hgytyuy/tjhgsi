package com.mathewsachin.libautomata.dagger

import javax.inject.Scope

@Scope
@Retention(value = AnnotationRetention.RUNTIME)
annotation class ScriptScope