package com.mathewsachin.libautomata

enum class HighlightColor {
    Error, Success, Warning, Info
}