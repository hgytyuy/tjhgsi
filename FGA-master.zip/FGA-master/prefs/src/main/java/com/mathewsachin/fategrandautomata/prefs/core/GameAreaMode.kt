package com.mathewsachin.fategrandautomata.prefs.core

enum class GameAreaMode {
    Default,
    Xperia,
    Duo,
    Custom
}